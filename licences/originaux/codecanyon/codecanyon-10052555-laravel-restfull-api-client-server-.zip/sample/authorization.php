<?php

require_once('../source/client/sximoapi.php');
$module = 'employee';
$api = new sximoapi('http://localhost/myapp/sximoapi','superadmin@mail.com:pLihtt-I4jzL');

?>